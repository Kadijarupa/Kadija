<?php
$conn = new mysqli("localhost", "root", "", "login_demo");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$name = $_POST['name'];
$email = $_POST['email'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $user = $result->fetch_assoc();
    
    if ($user['name'] === $name && password_verify($password, $user['password'])) {
        echo "<h2>Login Successful</h2>Welcome, " . htmlspecialchars($name);
    } else {
        echo "<h2>Login Failed</h2>Incorrect name or password.";
    }
} else {
    echo "<h2>Login Failed</h2>User not found.";
}

$stmt->close();
$conn->close();
?>