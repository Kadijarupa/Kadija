<?php
$conn = new mysqli("localhost", "root", "", "login_demo");

$name = "John Doe";
$email = "john@example.com";
$password = password_hash("12345", PASSWORD_DEFAULT);

$sql = "INSERT INTO users (name, email, password) VALUES ('$name', '$email', '$password')";

if ($conn->query($sql) === TRUE) {
    echo "User inserted successfully.";
} else {
    echo "Error: " . $conn->error;
}
$conn->close();
?>